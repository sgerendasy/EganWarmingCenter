package yilungao.gmail.com.eganwarmingcenter;


import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class Message extends AppCompatActivity {


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        messagingView = findViewById(R.id.messagingMain);
        setContentView(R.layout.msg_layout);
    }

}